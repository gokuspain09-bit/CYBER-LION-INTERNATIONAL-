# Mission and vision

## Mission
Support safer digital environments by sharing cybersecurity education, defensive research, and responsible open-source development.

## Vision
A collaborative, globally accessible community that values skill, integrity, privacy, and practical security.

## Commitments
1. Obtain permission before security testing.
2. Protect confidential information.
3. Publish accurate, reproducible, and safe educational material.
4. Credit authors and respect licenses.
5. Correct mistakes transparently.
