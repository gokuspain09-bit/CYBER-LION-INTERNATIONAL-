# Defensive tools catalogue

This folder is a catalogue for tools that support learning and defense. A listing is not an endorsement or guarantee of safety.

Suggested categories:
- Asset inventory for systems you own
- Log analysis and visualization
- File integrity monitoring
- Password-strength education using dummy examples
- Secure configuration checklists
- Dependency and secret scanning in your own repositories
- Local lab demonstrations

Do not add tools designed for credential theft, malware deployment, unauthorized access, evasion, disruption, or surveillance.
