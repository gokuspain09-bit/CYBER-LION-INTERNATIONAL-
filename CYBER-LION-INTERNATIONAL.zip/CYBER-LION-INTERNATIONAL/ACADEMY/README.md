# CYBER LION ACADEMY

A self-study learning path. It is educational material, not an accredited qualification or a job guarantee.

Start with the [roadmap](ROADMAP.md) and [course catalogue](COURSES.md). Practice only in your own lab, intentionally vulnerable training environments, or systems where you have written authorization.
