# Course catalogue

## Foundations
- Computer Fundamentals
- Internet & Networking Fundamentals
- Linux Fundamentals
- Python Programming
- Git & GitHub

## Cybersecurity
- Cybersecurity Fundamentals
- Security Principles & Risk Management
- Web Security Fundamentals
- Network Security Fundamentals
- Operating System Security
- Cloud Security Fundamentals
- AI Security Awareness

## Defensive practice
- Secure Configuration & Hardening
- Log Analysis & Monitoring
- Incident Response Fundamentals
- Digital Forensics Fundamentals
- OSINT Ethics & Privacy
- Vulnerability Management
- Secure Software Development

## Professional practice
- Security Reporting & Documentation
- Responsible Disclosure
- Threat Modelling
- Security Awareness & Communication

Each course should include learning objectives, prerequisites, safe exercises, references, and a knowledge check. Do not claim certification or accreditation unless formally obtained.
