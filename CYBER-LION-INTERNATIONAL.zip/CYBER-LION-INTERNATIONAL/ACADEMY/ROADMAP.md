# Learning roadmap

1. Computer and internet fundamentals
2. Linux and command-line basics
3. Networking fundamentals (IP, DNS, HTTP, TLS)
4. Python programming foundations
5. Web technologies and secure coding
6. Security principles, threat modelling, and risk
7. Operating-system and account hardening
8. Logs, monitoring, and incident-response fundamentals
9. Web, cloud, and network security concepts
10. Digital forensics and privacy fundamentals
11. Responsible vulnerability disclosure
12. Capstone: document and secure a self-owned lab

Recommended approach: learn the concept, complete a safe lab, write notes, and explain the defensive lesson.
