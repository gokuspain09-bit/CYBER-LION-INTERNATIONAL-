# Documentation

Guides and checklists for safer technology use and defensive security.

Planned guides:
- Personal account security
- Multi-factor authentication
- Device and operating-system updates
- Secure Wi-Fi configuration
- Backups and recovery
- Phishing awareness
- Secure software development
- Incident reporting
