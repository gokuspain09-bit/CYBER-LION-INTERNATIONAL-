# Secure GitHub repository checklist

- [ ] Enable two-factor authentication on maintainer accounts.
- [ ] Use least-privilege repository permissions.
- [ ] Protect the default branch and require review for important changes.
- [ ] Enable secret scanning and push protection when available.
- [ ] Keep dependencies updated.
- [ ] Never commit tokens, passwords, private keys, or personal data.
- [ ] Review GitHub Actions permissions and pin third-party actions appropriately.
- [ ] Publish a security contact and disclosure process.
- [ ] Back up important project data.
