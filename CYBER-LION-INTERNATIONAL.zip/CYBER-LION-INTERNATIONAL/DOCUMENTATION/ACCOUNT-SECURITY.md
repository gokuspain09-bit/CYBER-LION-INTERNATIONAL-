# Account security checklist

- Use a unique password for every important account.
- Use a reputable password manager.
- Enable multi-factor authentication where available.
- Keep recovery email addresses and phone numbers current.
- Review active sessions and connected applications.
- Be cautious with unexpected links, attachments, and login prompts.
- Never share one-time codes or recovery codes.
- Keep devices, browsers, and applications updated.
- Save recovery codes somewhere secure and private.
