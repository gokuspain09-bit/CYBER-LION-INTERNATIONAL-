# Learning resources

Use official documentation and reputable educational sources. Check dates, licenses, and author credentials.

## Standards and references
- OWASP: https://owasp.org/
- NIST Cybersecurity Framework: https://www.nist.gov/cyberframework
- CISA Secure Our World: https://www.cisa.gov/secure-our-world
- MITRE ATT&CK: https://attack.mitre.org/
- GitHub Security: https://docs.github.com/en/code-security

Add resources with a short description and avoid copying copyrighted course material.
