# Team

This folder describes project participation. Add only people who have explicitly agreed to be listed.

Do not publish private contact details, legal names, locations, photographs, or account identifiers without informed consent.

Suggested public profile fields:
- Display name
- Role
- Areas of interest
- Public profile link (optional)
- Contribution links
