# Suggested project roles

These are volunteer project roles, not professional certifications or proof of employment.

| Role | Contribution |
|---|---|
| Project Maintainer | Repository direction, reviews, releases |
| Security Research Contributor | Defensive research and safe write-ups |
| Developer | Open-source code and maintenance |
| Documentation Writer | Guides, tutorials, and translations |
| Academy Contributor | Learning material and lab design |
| Community Moderator | Community safety and conduct |
| Design Contributor | Branding and accessibility |

Assign roles only with the person's agreement. Do not claim qualifications that have not been verified.
