---
name: Feature request
about: Suggest a safe improvement
title: "[FEATURE] "
labels: enhancement
assignees: ""
---

## What would you like to add?

## Why is it useful?

## How would it remain safe, legal, and privacy-respecting?
