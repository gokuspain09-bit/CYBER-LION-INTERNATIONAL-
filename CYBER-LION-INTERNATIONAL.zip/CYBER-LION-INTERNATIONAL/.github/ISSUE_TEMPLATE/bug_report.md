---
name: Documentation or project issue
about: Report a problem in this repository
title: "[ISSUE] "
labels: documentation
assignees: ""
---

## What is the issue?

## Where did you find it?

## Expected improvement

## Additional context

Do not include secrets, personal data, or details about systems you do not own.
