# Research

Research should improve understanding and defensive security.

Acceptable topics include secure configuration, vulnerability classes explained at a high level, threat modelling, privacy, patch analysis, defensive detection, and controlled lab observations.

Do not publish personal data, live credentials, weaponized exploit chains, or instructions for compromising real targets. Use synthetic examples and isolated labs.
