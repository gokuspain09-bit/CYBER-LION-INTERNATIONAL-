# Research report

## Title
Short, factual title.

## Summary
What was studied and why?

## Scope and authorization
Describe the owned lab or written authorization. Do not identify third parties unnecessarily.

## Method
High-level, reproducible description suitable for a safe lab.

## Observations
What did you observe? Separate facts from assumptions.

## Defensive impact
Explain the risk from a defender's perspective.

## Recommendations
List practical mitigations and references.

## Disclosure
Describe who was notified and when, if applicable. Remove secrets and personal data.
