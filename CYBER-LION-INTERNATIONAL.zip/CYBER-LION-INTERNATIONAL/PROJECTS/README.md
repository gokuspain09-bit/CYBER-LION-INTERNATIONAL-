# Projects

A directory of community-built defensive tools, educational demos, and documentation.

## Project standards

Every project should include:
- A clear purpose and maintainer.
- Installation and usage instructions.
- License and dependencies.
- Safe defaults and limitations.
- A test or validation method.
- A warning if it interacts with networks or sensitive data.

Only add projects that comply with the repository's [Security Policy](../SECURITY.md).
