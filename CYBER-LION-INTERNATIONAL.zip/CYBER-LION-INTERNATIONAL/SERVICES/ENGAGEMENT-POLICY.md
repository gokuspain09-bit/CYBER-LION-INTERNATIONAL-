# Authorized engagement policy

Before any assessment:
1. Verify the system owner's identity and authority to grant permission.
2. Obtain written authorization.
3. Define exact assets, dates, methods, limits, and emergency contacts.
4. Agree on data handling, retention, and deletion.
5. Stop immediately if activity leaves the approved scope or risks harm.
6. Report findings privately and provide remediation guidance.

Never test public targets, accounts, networks, or devices without explicit permission. No denial-of-service, credential theft, persistence, stealth, or destructive testing is permitted under this project policy.
