# Capability areas

This page describes areas the project studies and teaches. It is not a promise of commercial services.

- Security awareness and secure-development education
- Defensive configuration and hardening guidance
- Authorized security assessment planning
- Web, network, cloud, and AI security learning
- OSINT methodology using lawful public sources
- Digital-forensics fundamentals
- Secure coding and code review education

Any real-world engagement must have a written agreement, defined scope, owner authorization, data-handling rules, and qualified personnel. Do not advertise a service as available until the team can safely and lawfully deliver it.
