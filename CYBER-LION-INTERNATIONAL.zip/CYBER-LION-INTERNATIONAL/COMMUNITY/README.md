# Community

Our community is for learning, collaboration, and responsible security.

## Community principles
- Respect people and privacy.
- Keep discussions legal and educational.
- Share sources and credit creators.
- Do not post personal data, leaked material, credentials, or harmful payloads.
- Ask for help in a clear and respectful way.

## FAQ

**Can beginners join?** Yes. Start with the Academy roadmap.

**Can I test a website I found?** No, not unless you own it or have explicit written permission.

**Does this repository provide certificates?** No. Do not claim an official certificate from this repository.

**How can I contribute?** Read CONTRIBUTING.md and open a focused pull request.
