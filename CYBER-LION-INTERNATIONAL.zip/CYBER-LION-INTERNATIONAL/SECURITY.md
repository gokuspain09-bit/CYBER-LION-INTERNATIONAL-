# Security Policy

## Scope

This repository contains educational material, documentation, and open-source project references. It is not an authorization to test any external system.

## Supported versions

Security reports are accepted for the latest version of the default branch. Older copies may not receive fixes.

## Reporting a vulnerability

Please do not publish exploitable details in a public issue.

Contact: **Add a monitored security contact email**

Include:
- A short description of the issue.
- The affected file, feature, or version.
- Safe reproduction details using a local lab or a system you own.
- Potential impact and suggested remediation, if known.

Do not include real users' personal data, secrets, or information obtained without authorization.

## Response

Maintainers will acknowledge reports when possible, assess the issue, and coordinate a fix and disclosure timeline with the reporter. Do not assume a response-time guarantee until one is formally published.
