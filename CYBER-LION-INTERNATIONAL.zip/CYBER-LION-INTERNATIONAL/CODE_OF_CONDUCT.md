# Code of Conduct

We want CYBER LION INTERNATIONAL to be a respectful, safe, and welcoming learning community.

## Expected behaviour

- Be respectful, constructive, and patient.
- Welcome beginners and explain concepts without ridicule.
- Respect privacy, consent, and intellectual property.
- Keep discussion focused on learning and defensive security.
- Disclose security issues responsibly.

## Unacceptable behaviour

- Harassment, threats, discrimination, doxxing, or intimidation.
- Sharing private information without consent.
- Encouraging illegal access, disruption, fraud, or harm.
- Posting malware, stolen credentials, or exploit material targeting real systems.
- Impersonating an organization, employee, or security professional.

## Reporting

Report concerns privately to the project maintainers using the contact method listed in the repository. Do not post sensitive personal information in public issues. Maintainers may edit, remove, or reject content and may restrict participation when necessary.
