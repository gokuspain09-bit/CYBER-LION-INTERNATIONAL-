# Contributing

Thank you for helping improve CYBER LION INTERNATIONAL.

## Good first contributions

- Fix typos and improve explanations.
- Translate beginner learning material.
- Add defensive security checklists.
- Improve accessibility and navigation.
- Add safe, self-contained lab exercises.
- Improve documentation or report templates.

## Before submitting

1. Search existing issues and pull requests.
2. Open an issue for large changes so the approach can be discussed.
3. Keep changes focused and explain why they help.
4. Never include passwords, API keys, personal data, private logs, or confidential client information.
5. Do not add code or instructions intended to compromise systems or bypass authorization.

## Pull request checklist

- [ ] I read the Code of Conduct.
- [ ] My change is relevant and clearly described.
- [ ] I tested links, examples, or code that I changed.
- [ ] I removed secrets and personal information.
- [ ] My contribution follows the project's legal and ethical boundaries.

By contributing, you agree that your contributions are provided under the repository's MIT License.
